const passport = require('passport');
const mongoose = require('mongoose');
const conn = require('../services/connect');
// models
const User = require('../models/User');
const Admin = require('../models/Admin');

const serializer = passport.serializeUser( function(user, done){

    return done(null, user.Id)
})


module.exports = serializer;