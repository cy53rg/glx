const passport = require('passport');
const mongoose = require('mongoose')
const conn = require('../services/connect');
const {getAdminById, getUserById} = require('../services/query');

// models
const User = require('../models/User');
const Admin = require('../models/Admin');


const deserialize = passport.deserializeUser(function(Id, done){

    // let adminquery = 'SELECT * FROM admin WHERE Id = ?';
    // let userquery = 'SELECT * FROM users WHERE Id = ?';
    const result = getAdminById(Id)
    result
    .then(user=>{

        if(user){
            
            return done(null, user);
        }

        getusers();
        
    })
    .catch(err=>{
    
        console.log(err);
    });


    function getusers(){
        const result_2 = getUserById(Id);

        result_2
        .then((user)=>{
           
            if(user){
                return done(null, user);
            }
        })
        .catch(err=>{
            console.log(err);
        })
    }
    
        
  


    // conn.query(userquery, id, (err, users)=>{

    //     if(users.length != 0){
            
    //         let user = users[0];
    //         conn.end();
    //         return done(null, user);

    //     }
    // })
 
    /*
    Admin.findById(id, (err,user)=>{

        if(user){
            return done(err, user)
        }

    })   
 
    
    User.findById(id, (err,user)=>{

        if(user){
            return done(err, user)
        }

    }) 
       */   
})

module.exports = deserialize;


