""[DMy first commit on the global invesment project"
