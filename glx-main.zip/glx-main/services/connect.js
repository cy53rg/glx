const sql = require('mysql');
const dotenv = require('dotenv')

dotenv.config({path: 'config/config.env'});

const conn = sql.createPool({
    host: process.env.DBHOST,
    user: process.env.DBUSER,
    password: process.env.DBPASSWORD ,
    database: process.env.DATABASE,
    port: process.env.DBPORT,
})


// const conn = sql.createPool({
//     host: 'localhost',
//     user: 'globalex_GLADMIN',
//     password: 'J%p_f1eTYlXW' ,
//     database: 'globalex_glxDB',
//     port: 3306,
// })




try {

    conn.getConnection(err=>{
        if (err){ throw err;
        }else{
            console.log('done')
        }
    })
    
} catch (err) {
    console.log(err)
}

 



module.exports = conn;