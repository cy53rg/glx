const sql = require('mysql');

const conn = require('./connect');

module.exports = {

    DeleteQuery: async (Id, table)=>{

        const query = `DELETE FROM ${table} WHERE Id = ?`

        try {
            const response = await new Promise((resolve, reject)=>{
                conn.query(query, Id, (err, done)=>{
                    if(err) reject(err);
                    resolve(done)
                });
            });
            return response;
            
        } catch (err) {
            console.log(err);
        }
    },

    addContact : async (body)=>{
        const query  = 'INSERT INTO contact (name, email, phoneNo, subject, message ) VALUES (?,?,?,?,?)';

        try {
            
            const response = await new Promise((resolve, reject)=>{
                conn.query(query, body, (err, result)=>{
                    if (err) reject(err.message);

                    resolve(result);
                })

            })

            
            return response;
        } catch (err) {
            console.log(err);
        }
    },

    passwordQuery: async (Id, password)=>{

        const query = `UPDATE users SET password = ?  WHERE Id = ?`

        try {
            const response = await new Promise((resolve, reject)=>{
                conn.query(query, [password, Id], (err, done)=>{
                    if(err) reject(err);
                    resolve(done)
                })
            })

            console.log(response);
            return response;
            
        } catch (err) {
            console.log(err);
        }
    },

    getAllUsers: async ()=>{

        const query = 'SELECT * FROM users';

        try {
            const response = await new Promise((resolve, reject)=>{
                conn.query(query, (err, users)=>{
                    if(err) reject(err);
                    resolve(users);
                })
            })

            console.log(response);
            return response;
            
        } catch (err) {
            console.log(err);
        }
    },

    getUserById: async (Id)=>{

        const query = 'SELECT * FROM users WHERE Id = ?';

        try {
            const response = await new Promise((resolve, reject)=>{
                conn.query(query, Id, (err, users)=>{
                    if(err) reject(err);
                    let [user] = users ;
                    resolve(user);
                })
            })

            
            return response;
            
        } catch (err) {
            console.log(err);
        }
    },

    getUserByEmail: async (email)=>{

        const query = 'SELECT * FROM users WHERE email = ?';

        try {
            const response = await new Promise((resolve, reject)=>{
                conn.query(query, email, (err, users)=>{
                    if(err) reject(err);
                    let [user] = users ;
                    resolve(user);
                })
            })

            
            return response;
            
        } catch (err) {
            console.log(err);
        }
    },

    getAdminById: async (Id)=>{

        const query = 'SELECT * FROM admin WHERE Id = ?';

        try {
            const response = await new Promise((resolve, reject)=>{
                conn.query(query, Id, (err, users)=>{
                    if(err) reject(err);
                    let [user] = users ;
                    resolve(user);
                })
            })

            return response;
            
        } catch (err) {
            console.log(err);
        }
    },

    getAll: async(table)=>{
        const query = `SELECT * FROM  ${table}`;

        try {
            
            const response = await new Promise((resolve, reject)=>{
                conn.query(query, (err, result)=>{
                    if (err) reject(err.message);

                    resolve(result);
                });
            });
            return response;
        } catch (err) {
            console.log(err);
        }
    },

    InsertCoin: async (table, body)=>{

        const query = `INSERT INTO ${table} (name, address) VALUES(?, ?)`;

        try {
            const response = await new Promise((resolve, reject)=>{

                conn.query(query, body, (err, result)=>{
                    if(err) reject(err.message);

                    resolve(result);
                });   
            });
            return response;
        } catch (err) {
            console.log(err);
        }
    },

    getAllnetwork: async (table, name)=>{

        const query = `SELECT * FROM ${table} WHERE name= ? `;
        try {
            const response = await new Promise((resolve, reject)=>{
                conn.query(query, name, (err, networks)=>{
                    if(err) reject(err.message);
                    const [network] = networks;
                    resolve(network);
                });
            });

            return response;
        } catch (err) {
            console.log(err);
        }
    },

    getTransactions: async ( id)=>{

        const query = `SELECT * FROM transaction WHERE user_Id= ? `;
        try {
            const response = await new Promise((resolve, reject)=>{
                conn.query(query, id, (err, transactions)=>{
                    if(err) reject(err.message);
                   
                    resolve(transactions);
                });
            });

            return response;
        } catch (err) {
            console.log(err);
        }
    },


    InsertTransaction: async (body)=>{

        const query = `INSERT INTO transaction (TransactionID, user_Id, type, amount, gateway, recieverAddress, network, status, proofImg) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)`;

        try {
            const response = await new Promise((resolve, reject)=>{

                conn.query(query, body, (err, result)=>{
                    if(err) reject(err.message);

                    resolve(result);
                });

              
            });
            return response;
        } catch (err) {
            console.log(err);
        }
    },


    InsertWithdraw: async (body)=>{

        const query = `INSERT INTO transaction (transactionID, user_Id, type, amount, gateway, recieverAddress,  network, status) VALUES(?, ?, ?, ?, ?, ?, ?, ?)`;

        try {
            const response = await new Promise((resolve, reject)=>{

                conn.query(query, body, (err, result)=>{
                    if(err) reject(err.message);

                    resolve(result);
                })

              
            })
            return response;
        } catch (err) {
            console.log(err);
        }
    },

    UpdateUser : async (body, column)=>{
        const query = `UPDATE users SET ${column} = ? WHERE Id= ? `;

        try {
            const response = await new Promise((resolve, reject)=>{

                conn.query(query, body, (err, result)=>{
                    if(err) reject(err.message);

                    resolve(result);
                })

               
            })
            return response;
        } catch (err) {
            console.log(err);
        }
    },

    UpdateTransaction : async (body)=>{
        const query = `UPDATE transaction SET status = ? WHERE Id= ? `;

        try {
            const response = await new Promise((resolve, reject)=>{

                conn.query(query, body, (err, result)=>{
                    if(err) reject(err.message);

                    resolve(result);
                })

               
            })
            return response;
        } catch (err) {
            console.log(err);
        }
    },
    UpdateUserBal: async (body)=>{
        const query = `UPDATE users SET accountBalance = ?, totalBalance = ? WHERE Id= ? `;

        try {
            const response = await new Promise((resolve, reject)=>{

                conn.query(query, body, (err, result)=>{
                    if(err) reject(err.message);

                    resolve(result);
                })

               
            })
            return response;
        } catch (err) {
            console.log(err);
        }
    },

    InsertUser: async (body)=>{

        const query = `INSERT INTO users (firstName, lastName, email, phoneNo, password) VALUES(?, ?, ?, ?, ?)`;

        try {
            const response = await new Promise((resolve, reject)=>{

                conn.query(query, body, (err, result)=>{
                    if(err) reject(err.message);

                    resolve(result);
                });

              
            });
            return response;
        } catch (err) {
            console.log(err);
        }
    },






}