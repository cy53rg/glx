const mongoose = require('mongoose');


const connectDB = async ()=>{
/*
    try {
        mongoose.set('strictQuery', true);
        //   mongoose.set('strictQuery', true);
         const conn = await mongoose.connect(process.env.MONGO_URI, {
            useNewUrlParser: false,
            useUnifiedTopology: true,
         })
         console.log(`database connected in ${conn.connection.host}`);
        
        
    } catch (err) {
        console.log(err);
        process.exit();
    }
    */
    
            mongoose.set('strictQuery', true);
        //   mongoose.set('strictQuery', true);
            await mongoose.connect(process.env.MONGO_URI, {
            useNewUrlParser: false,
            useUnifiedTopology: true,
         },(err)=>{
           if(!err){
              console.log('connected');
           }else{
              console.log(err);
           }
         })
}

module.exports = connectDB;
