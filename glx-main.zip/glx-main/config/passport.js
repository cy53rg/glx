const LocalStrategy = require('passport-local').Strategy;
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const passport = require('passport');
const serialize = require('../middleware/passport_Serialize');
const deserialize =  require('../middleware/passport_deserialize');
const conn = require('../services/connect');

// const {getUser, getAdmin} = require('../services/query');
const User = require('../models/User');
const Admin = require('../models/Admin');

module.exports = {
    UsersAuth: ()=>{
        passport.use('user_local', new LocalStrategy({usernameField: 'email'},
            (email, password, done)=>{
                console.log('user_local')
                try {

                    const query = 'SELECT * FROM users WHERE email= ?';
                    conn.query(query, email, (err, users, fields)=>{
                        if(err) throw err;
                        console.log(users);
                        if(users.length == 0){
                            // req.flash('error_msg', 'You do not have an account')
                            return done(null, false, {message : 'You do not have an account'})
                           

                        }

                        let user = users[0];
                       
                        bcrypt.compare(password, user.password, (err, isMatch)=>{
    
                            if(err){
                                console.log(err);
                            }
    
                            if(isMatch){
                                console.log('donnnnnn');
                                return done(null, user);
    
                            }else{
                                // req.flash('error_msg', 'incorrect password')
                                return done(null, false, {message: 'incorrect password'})
                            }
                            
                        })
                    })
                    /*
                    User.findOne({email:email}, (err, user)=>{
                        if(err){
                            return done(err, false)
                        }
                        if(!user){
                            // req.flash('error_msg', 'You do not have an account')
                            return done(null, false, {message : 'You do not have an account'})
                        }
                        
                        bcrypt.compare(password, user.password, (err, isMatch)=>{
    
                            if(err){
                                console.log(err)
                            }
    
                            if(isMatch){
                                console.log('donnnnnn')
                                return done(null, user)
    
                            }else{
                                // req.flash('error_msg', 'incorrect password')
                                return done(null, false, {message: 'incorrect password'})
                            }
                            
                        })
    
    
                    })
                    */
                } catch (err) {
                    req.flash('error_msg', err);
                }
                
            }

        ))
            serialize
            deserialize
    
    },

    AdminAuth: ()=>{

        passport.use('admin_local', new LocalStrategy(
            (username, password, done)=>{
                console.log('Admin_local')
                try {

                    let query = 'SELECT * FROM admin WHERE userName = ?';

                    conn.query(query, username, (err, users)=>{

                        if(users.length == 0){
                            return done(null, false, {message: 'unauthorized passonnel'});
                        }

                        let user = users[0];
                        
                        bcrypt.compare(password, user.password, (err, isMatch)=>{

                            if(err) throw err;

                            if(isMatch){
                                return done(null, user);
                            }

                            return done(null, false, {message: 'password incorrect'});
                        } )
                    })
                    /*
                    Admin.findOne({userName:username}, (err, user)=>{
                        if(err){
                            return done(err, false,{message: err})
                        }
                        if(!user){
                            // req.flash('error_msg', 'unauthorized user')
                            return done(null, false, {message : 'Unauthorized personnel'})
                        }
                        bcrypt.compare(password, user.password, (err, isMatch)=>{
    
                            if(err){
                                console.log(err)
                            }
    
                            if(isMatch){
                                return done(null, user)
    
                            }else{
                                // req.flash('error_msg', 'incorrect password')
                                return done(null, false, {message: 'incorrect password'})
                            }
                            
                        })
    
    
                    })
                    */
                    
                } catch (error) {
                    req.flash('error_msg', err)
                    console.log(err)
                }
                
            }

        ))
        serialize
        deserialize
        
    
    
    },
}
