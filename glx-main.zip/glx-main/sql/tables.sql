
CREATE TABLE admin ( 
    Id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    fullName VARCHAR(225) NOT NULL, 
    userName VARCHAR(225) NOT NULL UNIQUE, 
    email VARCHAR(225) NOT NULL, 
    password VARCHAR(225) NOT NULL,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE users ( 
    Id INT AUTO_INCREMENT NOT NULL PRIMARY KEY ,
    firstName VARCHAR(225) NOT NULL, 
    lastName VARCHAR(225) NOT NULL, 
    phoneNo VARCHAR(225) NOT NULL, 
    email VARCHAR(225) NOT NULL UNIQUE, 
    password VARCHAR(225) NOT NULL,
    plan VARCHAR(225), 
    profileImg VARCHAR(225), 
    accountBalance int(225) ,
    totalBalance int(225), 
    miningBalance int(225), 
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE contact ( 
    Id INT AUTO_INCREMENT NOT  PRIMARY KEY,
    name VARCHAR(225) NOT NULL, 
    email VARCHAR(225) NOT NULL, 
    phoneNo VARCHAR(225) NOT NULL, 
    subject VARCHAR(225), 
    message VARCHAR(1000),
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE transaction (
    Id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    TransactionID VARCHAR(100) NOT NULL UNIQUE ,
    user_Id INT NOT NULL,
    type VARCHAR(50) NOT NULL,
    amount INT,
    gateway VARCHAR(100) NOT NULL,
    recieverAddress VARCHAR(200),
    senderAddress VARCHAR(225),
    network VARCHAR(100),
    proofImg VARCHAR(200),
    status VARCHAR(20),
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE coins (
    Id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    tokeName VARCHAR(150) NOT NUll 
);


CREATE TABLE btc (
    Id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    address VARCHAR(225) NOT NUll
);

CREATE TABLE eth (
    Id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    address VARCHAR(225) NOT NUll
);

CREATE TABLE doge (
    Id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    address VARCHAR(225) NOT NUll
);

CREATE TABLE usdt (
    Id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    address VARCHAR(225) NOT NUll
);