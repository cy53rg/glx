const express = require('express');
const {ensureUserAuth} = require('../config/auth');
const {formatDate, transactionID} = require('../helper/helper');
const formidiable = require('formidable');
const router = express.Router()
const fs = require('fs');
const path = require('path');
const {depositReqMail, withdrawalReqMail} = require('../middleware/nodemailer');
const request = require('request');
// sql query

const {getAll, getAllnetwork, InsertTransaction, InsertWithdraw, getTransactions, UpdateUser} = require('../services/query');


// dashboard
router.get('/', ensureUserAuth, (req, res)=>{
    

    const result = getTransactions(req.user.Id);

    result
    .then(transactions=>{
                    
        res.render('dashboard', {user: req.user, transactions, formatDate, layout: 'LayoutC'});
    })
    .catch(err=>{
        req.flash('error_msg', 'error try again')
        res.redirect('/login');
    })




})



// @@deposit
// get
router.get('/deposit', ensureUserAuth, (req,res)=>{

    res.render('deposit', {user: req.user, layout: 'LayoutC'});
})

// get gateways     
router.post('/deposit/gateway', ensureUserAuth, (req,res)=>{
    const {Gateway} = req.body;

    const result = getAll(Gateway);

    result
    .then(network=>{
        
        res.render('deposit', {
            layout: 'LayoutC',
            user: req.user,
            Gateway,
            network,
        })
    })
    .catch(err=>{
        console.log(err);
    })

})

router.post('/deposit/networks', ensureUserAuth,(req,res)=>{

    const{Network, Gateway} = req.body;

    const result = getAll(Gateway);

    result
    .then(network=>{

        console.log(network)
        res.render('deposit', {
            layout: 'LayoutC',
            user: req.user,
            Gateway,
            Network,
            network,
        })

    })
    .catch(err=>{
        console.log(err);
    });
    
})


router.post('/deposit',ensureUserAuth, (req,res)=>{

    const form = new formidiable.IncomingForm()
    
        form.parse(req,(err, fields, files)=>{
            const transId = transactionID()
            const oldpath = files.proofImg.filepath;
            const newpath = path.join(`${__dirname}/../public/uploads/transactions`, files.proofImg.originalFilename)
            // form.uploadDir = 
            try {
                fs.rename(oldpath, newpath, (err)=>{

                    console.log(fields)
                    const transaction =[ 
                         transId, fields.Id, 'Deposit', fields.Amount, fields.GateWay,  fields.Address,  fields.Network, 'pending', files.proofImg.originalFilename,
                    ]

                    const result = InsertTransaction(transaction);

                    result
                    .then((done)=>{
                        if(done){
                            depositReqMail(req.user.email, transaction[3], req.user.firstName);
                            req.flash('success_msg', 'request submitted successfully');
                            req.flash('success_msg', 'account will be updated with 24hrs');
                            res.redirect('/dashboard/deposit');
                        }
                    })
                    .catch(err=>{
                        console.log(err);
                    })


                })
                    
            } catch (err) {
                console.log(err);
            }
           
    
            
    

        })
    
   
})

// end of deposit


// @@withdraw
//get
router.get('/withdraw', ensureUserAuth,  (req,res)=>{

    res.render('withdraw', {user: req.user, layout: 'LayoutC'});
})

// get gateways     
router.post('/withdraw/gateway', ensureUserAuth, (req,res)=>{
    const {Gateway} = req.body;

    const result = getAll(Gateway);

    result
    .then((network)=>{
        
        res.render('withdraw', {
            layout: 'LayoutC',
            user: req.user,
            Gateway,
            network,
        });


    })
    .catch(err=>{
        console.log(err);
    })
})


router.post('/withdraw/request', ensureUserAuth,(req,res)=>{

    const transId = transactionID()
    console.log(req.body);
    const transaction = [ transId, req.body.Id, 'withdraw', req.body.Amount, req.body.Gateway, req.body.Address, req.body.Network, 'pending' ]
  

    const result = InsertWithdraw(transaction);

    result
    .then((done)=>{

        if(done){
            withdrawalReqMail(req.user.email, transaction[3], req.user.firstName, transaction[5]);
            req.flash('success_msg', 'withdrawal request sent successfully');
            res.redirect('/dashboard/transactionslog');
        }
    })
    .catch(err=>{
        console.log(err);
    });
  
    
})


// @@tables
// get



// @@edit profile

router.get('/edit',ensureUserAuth,  (req,res)=>{


    res.render('edit', {
        user: req.user,
        layout: 'LayoutC',
    })
})

router.post('/edit',ensureUserAuth,  (req,res)=>{

    const {id, phoneNo}= req.body;

    const update = [phoneNo, id];

    const result = UpdateUser(update, 'phoneNo');

    result
    .then((done)=>{

        // if(err) throw err;

        if(done){
            req.flash('success-msg', 'profile updated');
            res.redirect('/dashboard/edit');
        }
        
    })  
    .catch(err=>{
        console.log(err);
    })

})

// upload image
router.post("/upload", ensureUserAuth, (req, res)=>{

    let forms = new formidiable.IncomingForm()
    forms.parse(req, (err, fields, files)=>{
        let oldpath = files.profileImg.filepath;
        let newpath =  path.join(`${__dirname}/../public/uploads/profileimages`, files.profileImg.originalFilename);
        forms.uploadDir = `${__dirname}/../uploads`;
        try {
            fs.rename(oldpath, newpath, ()=>{

                const update = [ files.profileImg.originalFilename, fields.id ]


                const result = UpdateUser(update, 'profileImg')

                result
                .then((done)=>{

                    // if(err) throw err;

                    if(done){
                        req.flash('success_msg', 'image upload sucessfully');
                        res.redirect('/dashboard/edit');
                    }
                })

                .catch(err=>{
                    console.log(err); 
                })
               
                
            })
                
        } catch (err) {
            console.log(err);
        }
        
    })

})

// end of edit



// transaction Logs

router.get('/transactionslog',ensureUserAuth, (req,res)=>{

    const result = getTransactions(req.user.Id);

    result
    .then((transactions)=>{

        if (transactions){
            res.render('transactionlog', {
                layout: 'layoutC',
                transactions,
                user: req.user,
                formatDate,
            });
        }
    })
    .catch(err=>{
        console.log(err);
    })

})









module.exports = router;