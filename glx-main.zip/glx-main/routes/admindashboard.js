const express = require('express');
const {ensureAdminAuth} = require('../config/auth');
const {formatDate} = require('../helper/helper');
const router = express.Router()


// nodemailer
const { withdrawalMail, rejectWithdrawalMail, depositFailureMail, depositMail} = require('../middleware/nodemailer');



// sql queries
const {DeleteQuery, getAllUsers, getAll, UpdateTransaction, UpdateUserBal, InsertCoin, getUserById} = require('../services/query');

// dashboard
router.get('/', ensureAdminAuth, (req,res)=>{
    console.log(req.user);

    const result = getAllUsers()
    result
    .then(users=>{
        // res.send(users);
        res.render('admindashboard', {user: req.user, formatDate, users, layout: 'LayoutC'})
    })
    .catch(err=>{
        req.flash('error_msg', 'unable to retrive users');
        res.redirect('/adminlogin');
    })

})

//@@transactions
// get
router.get('/transactions', ensureAdminAuth, (req,res)=>{

    const result = getAll('transaction');

    result
    .then(transactions=>{

        const users = getAll('users')

        users
        .then(Users=>{
            res.render('transactions', {user:req.user, transactions, Users, formatDate, layout: 'LayoutC'})
        })
        .catch(err=>{
            console.log(err);
        });

    })
    .catch(err=>{
        req.flash('error_msg', 'error try again')
        res.redirect('/dashboard');
    });

    
})

// @@ addcoins
router.get('/addcoin', ensureAdminAuth,  (req,res)=>{
    const context = [];


    try {
        const btcNetwork = getAll('btc')
    
        btcNetwork
        .then(btc=>{
           if(btc){
                
                const dogeNetwork = getAll('doge');
            
                dogeNetwork
                .then(doge=>{
                    if(doge){
                        const ethNetwork = getAll('eth')
    
                        ethNetwork
                        .then(eth=>{
                           if(eth){
                                const usdtNetwork = getAll('usdt')
                                usdtNetwork
                                .then(usdt=>{
                                    
                                    // res.send( btc, doge, eth, usdt);
                                    res.render('coin', {user: req.user, btc, doge, eth, usdt, layout: 'LayoutC'})
                                })
                                .catch(err=>{
                                    throw err;
                                });
                           }
                        })
                        .catch(err=>{
                            throw err;
                        });
                    }
                })
                .catch(err=>{
                    throw err;
                });
           };
        })
        .catch(err=>{
            throw err;
        });

        
    } catch (err) {
        console.log(err);
    }
    

});


router.post('/addcoin', ensureAdminAuth,  (req,res)=>{
    console.log(req.body)
    const{Name, Network, Address} = req.body;

    const result = InsertCoin(Name, [Network, Address]);
    result
    .then(done=>{
        if(done){
            req.flash('success_msg', 'Coin Added');
            res.redirect('/admindashboard/addcoin');
        }
    })
    .catch(err=>{
        console.log(err);
    })

})

router.post('/statusupdate', ensureAdminAuth, (req,res)=>{
    const {Id, userId, Type, Amount, Address, statusUpdate} =req.body;
    
    const update = [statusUpdate, Id]

    const result = UpdateTransaction(update);

    result
    .then((done)=>{

        if(done){
            getUserById(userId)
            .then(user=>{
                const {email, firstName} = user;

                if(user){
                    if(Type === 'withdraw'){
                        if(statusUpdate === 'success'){
                            const newAvailableBal = user.accountBalance - ((Amount *10)/10);
                            const totslBaln = user.totalBalance - ((Amount *10)/10) ;
                            let account = [newAvailableBal, totslBaln, userId];

                            UpdateUserBal(account)
                            .then(done=>{
                                if(done){
                                    withdrawalMail(email, Amount, firstName, Address);
                                req.flash('success_msg', 'status updated');
                                res.redirect('/admindashboard/transactions');
                                }
                            })
                            .catch(err=>{
                                console.log(err)
                            });
                            
                        }
                        if(statusUpdate === 'failed'){
                            rejectWithdrawalMail(email,Amount, firstName)
                            req.flash('success_msg', 'status updated')
                            res.redirect('/admindashboard/transactions')
                        }
                    }
                    if(Type === 'Deposit'){
                        if(statusUpdate === 'success'){

                            let acc = {
                                totalBalance: user.totalBalance + ((Amount *10)/10),
                                accountBalance: user.accountBalance + ((Amount *10)/10),
                            }
                            
                            let account = [acc.accountBalance, acc.totalBalance, userId];

                            UpdateUserBal(account)
                            .then(done=>{
                                if(done){
                                    depositMail(email, Amount, firstName);
                                    req.flash('success_msg', 'status updated');
                                    res.redirect('/admindashboard/transactions');
                                }
                            })
                            .catch(err=>{
                                console.log(err)
                            });
                          
                        }
                        if(statusUpdate === 'failed'){
                            depositFailureMail(email,Amount, firstName);
                            req.flash('success_msg', 'status updated');
                            res.redirect('/admindashboard/transactions');
                        }
                    }
                }

            })
            .catch(err=>{
                console.log(err);
            })
        }

    })
    .catch(err=>{
        console.log(err);
    })

});


// @@tables
// get
router.get('/contacts', ensureAdminAuth,  (req,res)=>{


    const result  = getAll('contact')

    result
    .then(contacts=>{
        res.render('contacts', {user: req.user, formatDate, contacts, layout: 'LayoutC'})

    })
    .catch(err=>{
        console.log(err)
    })

});



// logout
router.get('/logout', ensureAdminAuth, (req,res,next)=>{
    req.logout(err=>{
        if(err){
            console.log(err)
            return next(err)
        }
        req.flash('success_msg', 'logout successful')
        res.redirect('/adminlogin')
    })
});

// image view
router.get('/view/:image', ensureAdminAuth, (req,res)=>{

    res.render('view', {user: req.user, image: req.params.image, layout: 'LayoutC'})
});






module.exports = router;