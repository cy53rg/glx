const express = require('express');
const path = require('path');
const bcrypt = require('bcrypt');
const passport = require('passport');
const conn = require('../services/connect');
const router = express.Router();

// models
const User = require('../models/User');
const Admin = require('../models/Admin');
const Contact = require('../models/Contact');
const Coin = require('../models/Coin');


// nodemail middleware
const {registerMail,  passwordChangeMail} = require('../middleware/nodemailer');
const {DeleteQuery, InsertUser, passwordQuery, getUserByEmail, addContact, getUserById} = require('../services/query');

// @pages rouets
// home
router.get('/',  (req,res)=>{


    res.render('index');
});

// about
router.get('/about',  (req,res)=>{


    res.render('about');
});

router.get('/plan', (req,res)=>{


    res.render('Plan');
});
// router.get('/plan',  (req,res)=>{


//     res.sendFile('../pages/plan.html');
// });

// contacts
router.get('/contact', (req,res)=>{


    res.render('contact');
});
router.post('/contact',  (req,res)=>{

    const {name, email, subject, phone, message} = req.body;

    const contact = [name, email, subject, phone, message];
     const result = addContact(contact);

     result
     .then(done=>{
        if(done){
            req.flash('success_msg', 'message sent successfully. we will get back to soon! ');
            res.redirect('/contact');
        }
     })
     .catch(err=>{
        req.flash('error_msg', 'something went wrong... please try again');
        res.redirect('/contact');
     });
});


// @@login routes
// get
router.get('/login',  (req,res)=>{

    res.render('login');
});
router.post('/login', passport.authenticate('user_local', 
{
    session: true,
    failureRedirect: '/login',
    failureFlash: true
}), 
(req,res)=>{
    
    res.redirect('/dashboard');
}
);

// logout
router.get('/logout', (req,res,next)=>{
    req.logout(err=>{
        if(err){
            console.log(err);
            return next(err);
        }
        req.flash('success_msg', 'logout successful');
        res.redirect('/login');
    });
});


// @@registr routes
// get register
router.get('/register',  (req,res)=>{
 
    res.render('register');
});
router.post('/register',  (req,res)=>{
    const {firstname, lastname, email, phone, countryCode, password, password2  } = req.body ;

    const phoneNo = ()=>{

        return(countryCode + phone);
    };

    if (!firstname || !lastname || !email || !phone || !countryCode || !password || !password2 ){
        req.flash('error_msg', 'fill in all fields');
        res.redirect('/register');
    }else{
        if(password != password2){
            req.flash('error_msg', 'passwords do not match');
            res.redirect('/register');
        }else{

            try {

                bcrypt.genSalt( 8, (err, salt)=>{  
                    if (err) throw err;
                    bcrypt.hash(password, salt, (err, hash)=>{
                        if(err){
                            if(err) throw err.message;
                            res.redirect('/register');;
                        }else{
                            const body = [firstname, lastname, email, phoneNo(), hash];
                            const find  = getUserByEmail(email);

                            find
                            .then(user=>{
                                if(user){
                                    req.flash('error_msg', 'user already exixsts');
                                    res.redirect('/register');
                                }else{
                                    const result = InsertUser(body);

                                    result
                                    .then(done=>{

                                        if(done){
                                            registerMail(email, firstname);
                                            req.flash('success_msg', 'registerated successfully login');
                                            res.redirect('/login');
                                        }
                                    })
                                    .catch(err=>{
                                        if(err) throw err.message;
                                    });

                                }
                            }).catch(err=>{
                                if(err) throw err.message;
                            });
                            
                          
                        }
    
                        
                        
                    });
                 } );
   
            
            } catch (err) {
                console.log(err)
            }
         
        }
    
        
    }

    

})



// @@admin routes
// adminregister
// get
router.get('/adminregister', (req,res)=>{

    res.render('adminregister', {layout: 'LayoutC'})
})


// post
router.post('/adminregister', async (req,res)=>{
    const {name, username, email, password, password2} = req.body;
    if(password != password2){
        req.flash('error_msg', 'passwords do not match')
        res.render('adminregister', {layout: 'LayoutC', name, username, password, password2})
    }else{
        const query_1 = 'SELECT userName FROM admin WHERE userName = ?';
        await conn.query(query_1, username, (err, users)=>{
            const [user] = users;
            if (err) throw err;

            if(users.length != 0){
                req.flash('error_msg', 'username already exists')
                res.redirect('/adminregister')
            }else{
                bcrypt.genSalt(8, (err, salt)=>{

                    bcrypt.hash(password, salt, (err, hash)=>{

                        const query = 'INSERT INTO admin (fullName, username, email, password) VALUES (?, ?, ?, ?)';

                        conn.query(query, [name, username, email, hash], (err, done)=>{

                            if(err) throw err;

                            req.flash('success_msg', 'new admin created!')
                            res.redirect('/adminregister');
                        })
                    })
                } )
            }
        })
       

    }
})

// @@adminogin routes
// get
router.get('/adminlogin', (req,res)=>{

    res.render('adminlogin');
})


router.post('/adminlogin', passport.authenticate('admin_local', 
{
    failureRedirect: '/adminlogin',
    failureFlash: true}), 
(req,res)=>{

    res.redirect('/admindashboard')
}
)

// update User
router.post('/updateuser', (req, res)=>{
    const {id, plan, accBal, minBal, totalBal} = req.body;
  const Id = parseInt(id, 10)
    const query = 'UPDATE users SET plan = ?, accountBalance= ?, miningBalance= ?,  totalBalance=? WHERE Id = ?';

    try {
        conn.query(query,[plan, accBal, minBal, totalBal, Id], (err, done)=>{
            if(err) throw err;

            if (done){
                req.flash('success_msg', 'udated');
                res.redirect('/admindashboard');
            }
        })
        
    } catch (err) {
        req.flash('error_msg', 'error udating');
        res.redirect('/admindashboard');
    }


})

// delete user
router.get('/deleteuser/:id', (req,res)=>{

    const result = DeleteQuery(req.params.id, 'users');
    result
    .then((done)=>{

        if(done){
            req.flash('success_msg', 'deleted');
            res.redirect('/admindashboard');
        }
        
    })
    .catch((err)=>{
        console.log(err);
    })

})


// delete contacts
router.get('/deletecontact/:id', (req, res)=>{

    const result = DeleteQuery(req.params.id, 'contact')

    result
    .then(done=>{
        if(done){
            req.flash('success_msg', 'Deleted');
            res.redirect('/admindashboard/contacts');
        }
    }
    )
    .catch(err=>{
        console.log(err);
    });
    


})
router.get('/deletenetwork/:gateway/:network', (req, res)=>{
    console.log(req.params)
    
    const result = DeleteQuery(req.params.id, '')

    result
    .then(done=>{
        if(done){
            req.flash('success_msg', 'Deleted');
            res.redirect('/admindashboard/contacts');
        }
    }
    )
    .catch(err=>{
        console.log(err);
    });
})

router.get('/passrecovery', (req, res)=>{

    res.render('confirm');

})

router.post('/confirmemail', (req, res)=>{

    const {email} = req.body;
    const result  = getUserByEmail(email);

    result
    .then(user=>{
        if(user){
            const {email, firstName, Id} = user;
                passwordChangeMail(email, Id, firstName,)
                req.flash('success_msg', 'An email has been sent to you with steps on how to change your password')
                res.redirect('/passrecovery');
        }
    })
    .catch(err=>{
        console.log(err);
        req.flash('error_msg', 'Try again later');
                res.redirect('/passrecovery');
    });
 
    
})

router.get('/passchange/:id', (req,res)=>{
    
    const result  = getUserById(req.params.id);

    result
    .then(user=>{
        if(user != 'undefined'){
            res.render('password', {id: req.params.id});
        }
        else{
            res.redirect('/');
        }
    })
    .catch(err=>{
        console.log(err);
        req.flash('error_msg', 'Try again later');
                res.redirect('/passrecovery');
    });


})

router.post('/password', (req,res)=>{

    const {id, password, password2} = req.body;
    
    console.log(req.body)
    if(password != password2){
        req.flash('error_msg', 'passwords do not match')
        res.redirect(`/passchange/${id}`)
    }else{

        bcrypt.genSalt(8, (err, salt)=>{
            if(!err){
                console.log(salt);
                bcrypt.hash(password, salt, (err, hash)=>{
                    if(err) throw err;
                    console.log(hash);

                    const result = passwordQuery(id, hash)

                    result
                    .then(done=>{

                        if(done){
                            req.flash('success_msg', 'login');
                            res.redirect('/login');
                        }
                    })
                    .catch(err=>{
                        console.log(err);
                    });

                })
            }
        })
            
        
    }
});



module.exports = router;